#include<iostream>
#include<cstdio>
#include "omp.h"
#include<stdio.h>
#include<chrono>

using namespace std;
using namespace std::chrono;

void gen(int a[], int b[], int n)
{
    for(int i=0;i<n;i++)
    {
        a[i] = b[i] = n-i;
    }
}

void serial(int a[], int n)
{
    time_point<system_clock> start, end;
    start = system_clock::now();
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(a[j] > a[j+1])
            {
                int temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
    end = system_clock::now();
    duration<double> time = end - start;

    cout<<"The serial time is "<<time.count()*1000<<endl;
    
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";

    cout<<endl; 
}

void parallel(int b[], int n)
{
    time_point<system_clock> start, end;
    start = system_clock::now();

    int first = 0;
int i,j;
    for(i=0;i<n;i++)
    {
        first = i%2;
        #pragma omp parallel for default(none),shared(b,first,n)
        for(j=first;j<n-1;j=j+2)
        {
            if(b[j] > b[j+1])
            {
                int temp = b[j];
                b[j] = b[j+1];
                b[j+1] = temp;
            }
        }
    }

    end = system_clock::now();
    duration<double> time = end -start;

    cout<<"The parallel time is "<<time.count()*1000<<endl;

    for(int i=0;i<n;i++)
        cout<<b[i]<<" ";

    cout<<endl;
}

int main()
{
    cout<<"Enter size"<<endl;
    int n;cin>>n;

    int a[n];
    int b[n];

    gen(a,b,n);
    serial(a,n);
    parallel(b,n);

    cout<<endl;
    return 0;
}
