#include <iostream>
#include <cstdio>
#include <chrono>
using namespace std;
using namespace std::chrono;

float sum(int *a, int n)
{
    int sum = 0;
    
    for(int i=0;i<n;i++)
    {
        sum = sum + a[i];
    }
    float b = sum;
    return b;
}

int main()
{
    cout<<"Enter no. of elements"<<endl;
    int n;
    cin>>n;
    
    int a[n];
    
    for(int i=0;i<n;i++)
    {
        a[i] = i+1;
    }
    time_point<system_clock> start, end;
    start = system_clock::now();
    float res = sum(a, n);
    float mean = res/n;
    end = system_clock::now();
    duration<double> time = end - start;
    cout<<"Sum is "<<res<<endl;
    cout<<"Float is "<<mean<<endl;
    cout<<"Time "<<time.count()*1000<<endl;
    return 0;
}
