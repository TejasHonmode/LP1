import java.util.*;
import java.io.*;

public class Chat
{
	HashMap <String,String> train=new HashMap <String, String>();
	
	void communicate()
	{
		System.out.println("Hi, Ask me anything!");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		while(!s.equalsIgnoreCase("bye"))
		{
			if(train.containsKey(s))
			{	
				String esc = "\033[";
				System.out.print(esc + "2J");

				System.out.println("\033[Bot:"+train.get(s));
			}
			else
			{
				
				System.out.print("\033[New entry, train me!");
				String sAns=sc.nextLine();
				train.put(s, sAns);
			}
			s=sc.nextLine();
		}
	}
	
	public static void main(String args[]) throws IOException
	{
		Chat obj=new Chat();
		obj.communicate();
	}
}
