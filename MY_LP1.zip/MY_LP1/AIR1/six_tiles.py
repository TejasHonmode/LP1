import math
import random

goal = ['B', 'B', 'B', 'W', 'W', 'W', '_']

def index(item, sequence):
    if item in sequence:
        return sequence.index(item)
    return -1

class six_tiles:

    def __init__(self):
        self.conf = ['B', 'W', 'B', 'W', 'B', 'W', '_']
        self.depth = 0
        self.parent = None;
        self.hval = 0

    def __eq__(self, other):
        if self.__class__ != other.__class__:
            return False
        return self.conf == other.conf

    def __str__(self):
        res = ''
        for i in range(7):
            res+= self.conf[i] + ' '
        return res

    def locate(self):
        for i in range(7):
            if self.conf[i] == '_':
                return i

    def clone(self):
        cloned = six_tiles()
        for i in range(7):
            cloned.conf[i] = self.conf[i]
        return cloned

    def possible_moves(self):
        position = self.locate()
        possible = []

        if position < 6:
            possible.append(position+1)
        if position < 5:
            possible.append(position+2)
        if position > 0:
            possible.append(position-1)
        if position > 1:
            possible.append(position-2)

        return possible

    def swap(self, a, b):
        temp = self.conf[a]
        self.conf[a] = self.conf[b]
        self.conf[b] = temp

    def generate_all_combinations(self):
        moves = self.possible_moves()
        position = self.locate()

        def generate_and_clone(a,b):
            another_conf = self.clone()
            another_conf.swap(a,b)
            another_conf.depth = self.depth + 1
            another_conf.parent = self
            return another_conf
    
        return map(lambda pair: generate_and_clone(position, pair), moves)

    def generate_solution(self, path):
        if self.parent == None:
            return path
        else:
            path.append(self)
            return self.parent.generate_solution(path)

    def solve(self, h):
        def is_solve(puzzle):
            return puzzle.conf == goal

        Open = [self]
        Closed = []
        movecount = 0
        
        while len(Open) > 0:
            x = Open.pop(0)
            movecount+=1
            if is_solve(x):
                if len(Closed) > 0:
                    return x.generate_solution([]), movecount
                else:
                    return [x], 0

            successor = x.generate_all_combinations()
            open_index, closed_index = -1, -1

            for move in successor:
                open_index = index(move, Open)
                closed_index = index(move, Closed)
                hval = h(move)
                fval = hval + move.depth

                if open_index == -1 and closed_index == -1:
                    move.hval = hval
                    Open.append(move)

                elif open_index > -1:
                    copy = Open[open_index]
                    if fval < copy.hval + copy.depth:
                        copy.hval = hval
                        copy.parent = move.parent
                        copy.depth = move.depth

                elif closed_index > -1:
                    copy = Closed[closed_index]
                    if fval < copy.hval + copy.depth:
                        move.hval = hval
                        Closed.remove(copy)
                        Open.append(move)

            Closed.append(x)
            Open = sorted(Open, key = lambda p: p.hval + p.depth)

        return [], 0

def h_dist(tiles):
    count = 0
    for i in range(7):
        if tiles.conf[i] != goal[i]:
            count+=1
    return count

if __name__ == "__main__":
    six = six_tiles()

    print(six)

    path, count = six.solve(h_dist)
    path.reverse()
    for i in path:
        print(i)





























