import java.util.Scanner;

public class branch_bound {
    int n;

    void printSolution(int board[][])
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
                System.out.print(board[i][j]+" ");
            System.out.println();
        }
    }

    boolean isSafe(int row, int col, int slashCode[][],
                int backslashCode[][], boolean rowLookup[],
                boolean slashCodeLookup[], boolean backslashCodeLookup[] )
    {
        if(slashCodeLookup[slashCode[row][col]] || backslashCodeLookup[backslashCode[row][col]] ||
            rowLookup[row])
            return false;

        return true;
    }

    boolean solveNQUtil(int board[][], int col,
                          int slashCode[][], int backslashCode[][], boolean rowLookup[],
                          boolean slashCodeLookup[], boolean backslashCodeLookup[] )
    {
        if(col>=n)
            return true;

        for(int i=0;i<n;i++)
        {
            if(isSafe(i,col, slashCode, backslashCode, rowLookup,
                    slashCodeLookup, backslashCodeLookup))
            {
                board[i][col] = 1;
                rowLookup[i] = true;
                slashCodeLookup[slashCode[i][col]] = true;
                backslashCodeLookup[backslashCode[i][col]] = true;

                if(solveNQUtil(board, col+1, slashCode, backslashCode,
                        rowLookup, slashCodeLookup, backslashCodeLookup) )
                    return true;

                board[i][col] = 0;
                rowLookup[i] = false;
                slashCodeLookup[slashCode[i][col]] = false;
                backslashCodeLookup[backslashCode[i][col]] = false;
            }
        }
        return false;
    }

    boolean solveNQ()
    {
        int board[][] = new int[n][n];
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
                board[i][j]=0;
        }

        int slashCode[][] = new int[n][n];
        int backslashCode[][] = new int[n][n];

        boolean rowLookup[] = new boolean[n];
        for(int i=0;i<n;i++)
            rowLookup[i]=false;

        boolean slashCodeLookup[] = new boolean[2*n - 1];
        for(int i=0;i<2*n-1;i++)
            slashCodeLookup[i]=false;

        boolean backslashCodeLookup[] = new boolean[2*n - 1];
        for(int i=0;i<2*n-1;i++)
            backslashCodeLookup[i]=false;

        for (int r = 0; r < n; r++) {
            for (int c = 0; c < n; c++) {
                slashCode[r][c] = r + c;
                backslashCode[r][c] = r - c + n-1;
            }
        }

        if(solveNQUtil(board, 0, slashCode, backslashCode,
                rowLookup, slashCodeLookup, backslashCodeLookup) == false )
        {
            System.out.println("solution does not exist");

            return false;
        }
        
        printSolution(board);

        return true;
    }

    void setN(int n)
    {
        this.n=n;
    }



    public static void main(String[] args) {
        branch_bound q = new branch_bound();

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter value of N");
        int n = sc.nextInt();
        q.setN(n);
        q.solveNQ();
    }
}

        
