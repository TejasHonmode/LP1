class expert_systems():
    def __init__(self):
        self.source = 'symtomps'
        self.symtomps_dict = {}
        self.symtomps_to_disease = {}

    def read(self):
        reader = open(self.source, 'r')

        for line in reader:
            tokens = line.split(',')
            filtered_tokens = []
            disease_name = tokens[0].strip()[1:-1]

            n = len(tokens)
            for i in range(1,n):
                curr = tokens[i].strip()
                filtered_tokens.append(curr)
                try:
                    self.symtomps_to_disease[curr].append(disease_name)
                except:
                    self.symtomps_to_disease[curr] = list()
                    self.symtomps_to_disease[curr].append(disease_name)

            self.symtomps_dict[disease_name] = filtered_tokens

    def detect(self):
        symtomps = input("Enter symtomps")
        tokens = symtomps.split(',')
        filtered_tokens = []

        for token in tokens:
            filtered_tokens.append(token.strip().lower())

        print (filtered_tokens)

        for ft in filtered_tokens:
            try:
                disease_names = self.symtomps_to_disease[ft]
                visited = set()
                for disease_name in disease_names:
                    if disease_name in visited:
                        continue
                    disease_symtomps = self.symtomps_dict[disease_name]
                    self.calc_prob(disease_name, disease_symtomps, filtered_tokens)
                    visited.add(disease_name)
            
            except KeyError:
                print("Unable to find disease for :" + ft)
                continue

    def calc_prob(self, disease_name, disease_symtomps, user_input):
        n = len(disease_symtomps)
        count = 0
        for symtomp in user_input:
            if symtomp in disease_symtomps:
                count+=1
        print ("Probability that disease is: "+ disease_name + " = " + str(count/n))

expert_system = expert_systems()
expert_system.read()
expert_system.detect()
